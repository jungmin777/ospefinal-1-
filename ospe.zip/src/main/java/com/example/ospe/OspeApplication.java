package com.example.ospe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OspeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OspeApplication.class, args);
	}

}
